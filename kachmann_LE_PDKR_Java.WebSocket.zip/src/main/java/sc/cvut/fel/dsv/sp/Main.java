package sc.cvut.fel.dsv.sp;

import sc.cvut.fel.dsv.sp.topology.Node;

public class Main {

    public static void main(String[] args) {
        Node node = new Node();

        node.init();
        node.run();
    }

}