package sc.cvut.fel.dsv.sp.topology;

public enum StateNode {
    ACTIVE, // init state
    PASSIVE,
    LEADER,
    LOST
}
