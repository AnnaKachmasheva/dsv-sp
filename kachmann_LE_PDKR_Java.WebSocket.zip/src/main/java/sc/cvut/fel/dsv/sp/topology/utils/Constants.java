package sc.cvut.fel.dsv.sp.topology.utils;

public class Constants {

    public static final String
            NEW_RIGHT_NEIGHBOUR = "New right neighbour",
            NEW_LEFT_NEIGHBOUR = "New left neighbour",
            GET_RIGHT_NEIGHBOUR = "Get right neighbour",
            MY_RIGHT_NEIGHBOUR = "My right neighbour",
            REPAIR = "REPAIR",
            NEW_ROUND_INIT = "NEW ROUND INIT",
            START_ROUND = "START ROUND",
            CIP = "CIP",
            ACNP = "ACNP",
            WIN = "WIN",
            WINNER = "WINNER",
            PING = "ping";
}
